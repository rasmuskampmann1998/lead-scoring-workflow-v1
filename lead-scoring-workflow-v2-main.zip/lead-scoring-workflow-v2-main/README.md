Built on data from → https://github.com/<your-username>/lead-scoring-workflow-v1
